import Nav from '@/components/Nav';
import WhatsAppFloat from '@/components/WhatsAppFloat';
export const metadata = {
  title: "Inari Luxury — AI-Enabled Premium Concierge"
};
export default function LangLayout({ children }: { children: React.ReactNode }){
  return (<html lang="en"><body>
    <Nav lang="en" />
    <main className="min-h-screen">{children}</main>
    <footer className="border-t border-white/10 py-8"><div className="container text-sm text-white/60">© Inari Luxury. By-appointment only.</div></footer>
    <WhatsAppFloat />
  </body></html>);
}
