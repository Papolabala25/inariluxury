'use client'; import { useState } from 'react';
export default function Page(){
  const [ok,setOk]=useState(false);
  async function onSubmit(e){ e.preventDefault(); const data=Object.fromEntries(new FormData(e.currentTarget).entries());
    const res = await fetch('/api/eligibility', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data)});
    if(res.ok) setOk(true);
  }
  return (<section className='container py-12'><h1>Eligibility Review</h1>
    {ok? <div className='card mt-6'>Thank you. We will contact you within 24h.
      <div className='mt-6'><a className='btn btn-primary' target='_blank' href={'https://wa.me/526121171197?text='+encodeURIComponent('I submitted my eligibility request and would like to coordinate a private call.')}>Open WhatsApp</a></div>
    </div> :
    <form onSubmit={onSubmit} className='card mt-6 grid gap-3'>
      <input name='name' placeholder='Full Name' required className='rounded-xl bg-white/10 px-3 py-2 outline-none'/>
      <input name='email' type='email' placeholder='Email' required className='rounded-xl bg-white/10 px-3 py-2 outline-none'/>
      <input name='nationality' placeholder='Nationality & Residency' required className='rounded-xl bg-white/10 px-3 py-2 outline-none'/>
      <button className='btn btn-primary mt-2' type='submit'>Request Eligibility Review</button>
    </form>}
  </section>);
}
