import Link from 'next/link';
export default function HeroVideo({ lang }: { lang: 'en'|'es' }){
  return (<section className="relative overflow-hidden">
    <video className="absolute inset-0 h-full w-full object-cover opacity-40" autoPlay loop muted playsInline>
      <source src="https://cdn.coverr.co/videos/coverr-luxury-yacht-ride-8946/1080p.mp4" type="video/mp4" />
    </video>
    <div className="relative">
      <div className="container py-24 md:py-36">
        <div className="badge mb-6 bg-black/30">{lang==='en'?'By approval only':'Solo con pre-aprobación'}</div>
        <h1 className="mb-4">{lang==='en'?'AI-Enabled Premium Concierge — Admission by Pre-Approval':'Concierge premium con IA — Acceso por pre-aprobación'}</h1>
        <p className="mb-8 max-w-2xl">{lang==='en'
          ?'Trusted, curated access to experiences not available to the public. For eligible high-net-worth clients only.'
          :'Acceso curado a experiencias no disponibles al público. Solo para HNWIs elegibles.'}</p>
        <div className="flex items-center gap-3">
          <Link href={`/${lang}/eligibility`} className="btn btn-primary">{lang==='en'?'Request Eligibility Review':'Solicitar revisión de elegibilidad'}</Link>
          <Link href={`/${lang}/ai-concierge`} className="btn" style={{border:'1px solid rgba(255,255,255,.2)'}}>{lang==='en'?'How our AI Concierge works':'Cómo funciona nuestro Concierge IA'}</Link>
        </div>
      </div>
    </div>
  </section>);
}
