import './globals.css';
export const metadata = {
  title: 'Inari Luxury — AI-Enabled Premium Concierge',
  description: 'Selective, AI-powered concierge for HNWIs. Curated, verified premium experiences. Not open to the public.',
  metadataBase: new URL('https://inari.example.com')
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en"><body>{children}</body></html>);
}
