import Link from 'next/link';
export default function Nav({ lang }: { lang:'en'|'es' }){
  const base = lang==='en'?'/en':'/es';
  const other = lang==='en'?'/es':'/en';
  return (<header className="border-b border-white/10">
    <div className="container flex items-center justify-between py-4">
      <Link href={base} className="flex items-center gap-3">
        <img src="/assets/inari-logo.svg" alt="Inari Luxury" className="h-8 w-auto" /><span className="sr-only">Inari</span>
      </Link>
      <nav className="flex items-center gap-6 text-sm">
        <Link href={`${base}/ai-concierge`}>AI Concierge</Link>
        <Link href={`${base}/experiences`}>{lang==='en'?'Experiences':'Experiencias'}</Link>
        <Link href={`${base}/eligibility`}>{lang==='en'?'Eligibility':'Elegibilidad'}</Link>
        <Link href={`${base}/about`}>{lang==='en'?'About':'Nosotros'}</Link>
        <Link href={`${base}/partners`}>{lang==='en'?'Partners':'Socios'}</Link>
        <Link href={`${base}/press`}>{lang==='en'?'Press':'Prensa'}</Link>
        <Link href={`${base}/policies`}>{lang==='en'?'Policies':'Políticas'}</Link>
        <Link href={`${base}/contact`}>{lang==='en'?'Contact':'Contacto'}</Link>
        <Link href={other} className="ml-2 inline-flex items-center gap-1 rounded-lg border border-white/10 px-3 py-1">{lang==='en'?'ES':'EN'}</Link>
      </nav>
    </div>
  </header>);
}
