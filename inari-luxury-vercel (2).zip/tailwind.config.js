module.exports = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: { extend: { colors: { gold: "#D8B46A", dark: "#0E0E0E" } } },
  plugins: []
};
