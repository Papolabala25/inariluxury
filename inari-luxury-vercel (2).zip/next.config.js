/** @type {import('next').NextConfig} */
const nextConfig = { experimental: { typedRoutes: true } };
nextConfig.redirects = async () => ([{ source: '/', destination: '/en', permanent: false }]);
module.exports = nextConfig;
