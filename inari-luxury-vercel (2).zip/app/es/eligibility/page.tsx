'use client'; import { useState } from 'react';
export default function Page(){
  const [ok,setOk]=useState(false);
  async function onSubmit(e){ e.preventDefault(); const data=Object.fromEntries(new FormData(e.currentTarget).entries());
    const res = await fetch('/api/eligibility', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data)});
    if(res.ok) setOk(true);
  }
  return (<section className='container py-12'><h1>Revisión de Elegibilidad</h1>
    {ok? <div className='card mt-6'>Gracias. Te contactaremos dentro de 24h.
      <div className='mt-6'><a className='btn btn-primary' target='_blank' href={'https://wa.me/526121171197?text='+encodeURIComponent('He enviado mi solicitud de elegibilidad y deseo coordinar una llamada privada.')}>Abrir WhatsApp</a></div>
    </div> :
    <form onSubmit={onSubmit} className='card mt-6 grid gap-3'>
      <input name='name' placeholder='Nombre completo' required className='rounded-xl bg-white/10 px-3 py-2 outline-none'/>
      <input name='email' type='email' placeholder='Email' required className='rounded-xl bg-white/10 px-3 py-2 outline-none'/>
      <input name='nationality' placeholder='Nacionalidad y residencia' required className='rounded-xl bg-white/10 px-3 py-2 outline-none'/>
      <button className='btn btn-primary mt-2' type='submit'>Solicitar revisión de elegibilidad</button>
    </form>}
  </section>);
}
