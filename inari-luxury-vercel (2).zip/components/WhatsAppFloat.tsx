'use client';
import { usePathname } from 'next/navigation';
export default function WhatsAppFloat(){
  const pathname = usePathname();
  const isES = pathname.startsWith('/es');
  const number = '526121171197';
  const text = encodeURIComponent(isES
    ? 'Hola Inari. He enviado mi solicitud de elegibilidad y deseo coordinar una llamada privada.'
    : 'Hello Inari. I submitted my eligibility request and would like to coordinate a private call.');
  return <a href={`https://wa.me/${number}?text=${text}`} target="_blank"
    className="fixed bottom-6 right-6 z-50 rounded-full bg-[#25D366] px-5 py-3 font-semibold text-black shadow-2xl hover:opacity-90">WhatsApp</a>;
}
